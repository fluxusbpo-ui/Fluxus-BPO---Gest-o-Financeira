exports.up = function(knex) {
  return knex.schema.createTable('planos', function(t) {
    t.uuid('id').primary();
    t.string('stripe_price_id');
    t.string('nome').notNullable();
    t.integer('max_empresas').defaultTo(0);
    t.integer('max_usuarios').defaultTo(0);
    t.json('funcionalidades');
    t.timestamps(true, true);
  });
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('planos');
};
