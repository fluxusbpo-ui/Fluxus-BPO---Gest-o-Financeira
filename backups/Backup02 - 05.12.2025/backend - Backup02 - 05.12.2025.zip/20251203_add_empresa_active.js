exports.up = function(knex) {
  return knex.schema.hasColumn('empresas', 'active').then(function(has){
    if (!has) {
      return knex.schema.alterTable('empresas', function(t){
        t.boolean('active').defaultTo(false);
      });
    }
  });
};

exports.down = function(knex) {
  return knex.schema.hasColumn('empresas', 'active').then(function(has){
    if (has) {
      return knex.schema.alterTable('empresas', function(t){
        t.dropColumn('active');
      });
    }
  });
};
