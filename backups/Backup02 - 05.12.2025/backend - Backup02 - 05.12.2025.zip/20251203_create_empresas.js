exports.up = function(knex) {
  return knex.schema.createTable('empresas', function(t) {
    t.uuid('id').primary();
    t.string('razao_social').notNullable();
    t.string('cnpj').notNullable();
    t.string('telefone');
    t.string('email');
    t.timestamps(true, true);
  });
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('empresas');
};
