exports.up = function(knex) {
  return knex.schema.hasColumn('assinaturas', 'checkout_session_id').then(function(has){
    if (!has) {
      return knex.schema.alterTable('assinaturas', function(t){
        t.string('checkout_session_id');
      });
    }
  });
};

exports.down = function(knex) {
  return knex.schema.hasColumn('assinaturas', 'checkout_session_id').then(function(has){
    if (has) {
      return knex.schema.alterTable('assinaturas', function(t){
        t.dropColumn('checkout_session_id');
      });
    }
  });
};
