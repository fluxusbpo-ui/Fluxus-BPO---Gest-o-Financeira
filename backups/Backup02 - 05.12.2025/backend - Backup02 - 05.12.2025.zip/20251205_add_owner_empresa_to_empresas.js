exports.up = function(knex) {
  return knex.schema.hasColumn('empresas', 'owner_empresa_id').then(function(has){
    if (!has) {
      return knex.schema.alterTable('empresas', function(t){
        t.uuid('owner_empresa_id').nullable().after('id');
      }).then(function(){
        // Backfill owner_empresa_id = id for existing rows
        return knex.raw('update empresas set owner_empresa_id = id where owner_empresa_id is null');
      });
    }
  });
};

exports.down = function(knex) {
  return knex.schema.hasColumn('empresas', 'owner_empresa_id').then(function(has){
    if (has) return knex.schema.alterTable('empresas', function(t){ t.dropColumn('owner_empresa_id'); });
  });
};
