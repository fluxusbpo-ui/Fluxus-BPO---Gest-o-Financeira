'use strict'

// XXX remove in v8 or beyond
module.exports = require('./index.js')
