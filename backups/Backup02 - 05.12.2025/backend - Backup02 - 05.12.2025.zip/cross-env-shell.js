#!/usr/bin/env node

const crossEnv = require('..')

crossEnv(process.argv.slice(2), {shell: true})
