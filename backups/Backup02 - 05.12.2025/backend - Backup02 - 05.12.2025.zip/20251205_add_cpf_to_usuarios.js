exports.up = function(knex) {
  return knex.schema.table('usuarios', function(t){
    // adiciona coluna cpf (opcional) e índice único para evitar duplicidade
    t.string('cpf').nullable().unique();
  });
};

exports.down = function(knex) {
  return knex.schema.table('usuarios', function(t){
    t.dropColumn('cpf');
  });
};
