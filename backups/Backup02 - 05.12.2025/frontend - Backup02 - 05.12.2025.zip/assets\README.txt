Por favor, salve a imagem de engrenagem que você enviou como `gear.png` nesta pasta.
Nome do arquivo esperado: frontend/assets/gear.png

Observações:
- O HTML já foi atualizado para usar a imagem em `/assets/gear.png`.
- Se você preferir, pode substituir este arquivo manualmente com a imagem exata do anexo enviado.
- Após colocar a imagem, recarregue o frontend (Vite) para ver a alteração imediatamente.

Comandos úteis (PowerShell):
# Copiar a imagem do local para esta pasta (exemplo):
# Copy-Item -Path "C:\Users\Voce\Downloads\gear.png" -Destination "d:\Dev\GeP Finance\frontend\assets\gear.png"

# Reiniciar o servidor dev (no diretório frontend):
# npm run dev
