// Arquivo de entrada para o frontend estático. Mantido vazio — comportamento estático via HTML/CSS.
console.log('Frontend estático carregado');

// Mobile header toggle: find header toggle buttons and bind open/close behavior
;(function(){
	function qs(sel, root=document){return root.querySelector(sel)}
	function qsa(sel, root=document){return Array.from(root.querySelectorAll(sel))}

	qsa('.header-toggle').forEach(btn=>{
		btn.addEventListener('click', function(e){
			const headerInner = btn.closest('.header-inner')
			if(!headerInner) return
			const opened = headerInner.classList.toggle('open')
			btn.setAttribute('aria-expanded', opened ? 'true' : 'false')
		})
	})

	// close when clicking outside
	document.addEventListener('click', function(e){
		const openHeader = document.querySelector('.header-inner.open')
		if(!openHeader) return
		if(openHeader.contains(e.target)) return
		openHeader.classList.remove('open')
		const t = openHeader.querySelector('.header-toggle')
		if(t) t.setAttribute('aria-expanded','false')
	})

	// close on ESC
	document.addEventListener('keydown', function(e){
		if(e.key === 'Escape'){
			const openHeader = document.querySelector('.header-inner.open')
			if(openHeader) openHeader.classList.remove('open')
		}
	})
})();

