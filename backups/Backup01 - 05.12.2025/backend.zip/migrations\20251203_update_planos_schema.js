exports.up = function(knex) {
  return knex.schema.hasColumn('planos', 'preco_mensal').then(function(has){
    const chain = [];
    if (!has) {
      chain.push(knex.schema.alterTable('planos', function(t){
        t.decimal('preco_mensal', 10, 2).defaultTo(0);
      }));
    }
    return Promise.all(chain).then(function(){
      return knex.schema.hasColumn('planos', 'modulos').then(function(hasMod){
        if (!hasMod) {
          return knex.schema.alterTable('planos', function(t){
            t.json('modulos');
          });
        }
      });
    });
  });
};

exports.down = function(knex) {
  return knex.schema.hasColumn('planos', 'modulos').then(function(hasMod){
    if (hasMod) {
      return knex.schema.alterTable('planos', function(t){
        t.dropColumn('modulos');
      });
    }
  }).then(function(){
    return knex.schema.hasColumn('planos', 'preco_mensal').then(function(has){
      if (has) {
        return knex.schema.alterTable('planos', function(t){
          t.dropColumn('preco_mensal');
        });
      }
    });
  });
};
