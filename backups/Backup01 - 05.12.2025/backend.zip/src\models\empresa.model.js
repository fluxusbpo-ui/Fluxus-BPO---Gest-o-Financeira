const db = require('../config/db');

async function createEmpresa({ id, razao_social, cnpj, telefone, email }) {
  return db('empresas').insert({ id, razao_social, cnpj, telefone, email });
}

async function getEmpresaById(id) {
  return db('empresas').where({ id }).first();
}

async function listEmpresas() {
  return db('empresas').select('*');
}

async function deleteEmpresa(id) {
  return db('empresas').where({ id }).del();
}

module.exports = { createEmpresa, getEmpresaById, listEmpresas, deleteEmpresa };
