const db = require('../config/db');

async function createUsuario(obj) {
  return db('usuarios').insert(obj);
}

async function findByEmail(email) {
  return db('usuarios').where({ email }).first();
}

async function getUsuarioById(id) {
  return db('usuarios').where({ id }).first();
}

module.exports = { createUsuario, findByEmail, getUsuarioById };
