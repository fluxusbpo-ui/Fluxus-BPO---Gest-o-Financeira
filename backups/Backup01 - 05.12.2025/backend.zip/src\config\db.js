// Exporta a instância do Knex já existente em ../db.js
module.exports = require('../db');
