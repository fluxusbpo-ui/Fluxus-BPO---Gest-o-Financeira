const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const { v4: uuidv4 } = require('uuid');
const db = require('./db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { sendConfirmationEmail, sendContactEmail } = require('./mailer');
const { mockAuthFromHeaders, requirePermission } = require('./permissions');
const { requireRole } = require('./middleware/role.middleware');
const { PERMISSIONS, ROLES } = require('./roles');

const port = process.env.PORT || 5000;

// middleware
app.use(express.json());

// simple CORS for local dev
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// Auth: try JWT, otherwise fallback to dev headers
const { auth } = require('./middleware/auth.middleware');
app.use(auth);

const dataDir = path.join(__dirname, '..', 'data');
const contactsFile = path.join(dataDir, 'contacts.json');

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

if (!fs.existsSync(contactsFile)) {
  fs.writeFileSync(contactsFile, JSON.stringify([],null,2));
}

app.get('/health', (req, res) => {
  res.json({ status: 'ok', port });
});

app.get('/', (req, res) => {
  res.send(`Backend rodando na porta ${port}`);
});

// Plans & Checkout routes
const planController = require('./controllers/plan.controller');
const bodyParser = require('body-parser');

app.get('/plans', planController.listPlans);

// Create checkout session (uses Stripe if configured)
app.post('/checkout/create-session', express.json(), planController.createCheckoutSession);

// Stripe webhook: use raw body for signature validation when Stripe is configured
app.post('/webhook/stripe', express.raw({ type: 'application/json' }), planController.handleWebhook);

// ---------- Auth: Register company + master user ----------
app.post('/auth/register', async (req, res) => {
  const { razao_social, cnpj, nome_responsavel, telefone, email, senha, confirmar_senha } = req.body || {};
  if (!razao_social || !cnpj || !nome_responsavel || !email || !senha || !confirmar_senha) {
    return res.status(400).json({ error: 'Campos obrigatórios ausentes' });
  }
  if (senha !== confirmar_senha) return res.status(400).json({ error: 'Senhas não conferem' });

  // simples validação CNPJ/CPF: apenas dígitos e comprimento 11 ou 14
  const digits = (cnpj || '').toString().replace(/\D/g, '');
  if (![11,14].includes(digits.length)) {
    return res.status(400).json({ error: 'CNPJ/CPF inválido (esperado 11 ou 14 dígitos)'});
  }


  try {
    // checar email único
    const existing = await db('usuarios').where({ email }).first();
    if (existing) return res.status(400).json({ error: 'Email já cadastrado' });

    // checar CNPJ/CPF único
    if (digits.length === 14) {
      // se já existe empresa com este CNPJ, bloquear registro
      const existEmpresa = await db('empresas').where({ cnpj: digits }).first();
      if (existEmpresa) return res.status(400).json({ error: 'CNPJ já cadastrado' });
    } else if (digits.length === 11) {
      // se for CPF, verificar se já existe usuário com mesmo CPF (se coluna cpf presente)
      const hasCpfColumn = await db.schema.hasColumn('usuarios', 'cpf');
      if (hasCpfColumn) {
        const existCpf = await db('usuarios').where({ cpf: digits }).first();
        if (existCpf) return res.status(400).json({ error: 'CPF já cadastrado' });
      }
    }

    // criar empresa
    const empresaId = uuidv4();
    await db('empresas').insert({ id: empresaId, razao_social, cnpj: digits, telefone, email });

    // criar usuário master
    const userId = uuidv4();
    const senha_hash = bcrypt.hashSync(senha, 10);
    // prepare user insert payload; include cpf when present
    const userPayload = { id: userId, empresa_id: empresaId, nome: nome_responsavel, email, telefone, senha_hash, role: ROLES.MASTER, email_confirmed: false };
    try {
      const hasCpfColumn = await db.schema.hasColumn('usuarios', 'cpf');
      if (hasCpfColumn && digits.length === 11) userPayload.cpf = digits;
    } catch(e) { /* ignore */ }

    await db('usuarios').insert(userPayload);

    // gerar token de confirmação
    const token = uuidv4();
    const expiresAt = new Date(Date.now() + (1000 * 60 * 60 * 24)); // 24h
    await db('email_tokens').insert({ id: uuidv4(), user_id: userId, token, expires_at: expiresAt });

    // enviar email (dev: mailer loggar se SMTP não configurado)
    const mailRes = await sendConfirmationEmail(email, token, { confirmUrl: process.env.CONFIRM_URL || `http://localhost:3001/auth/confirm?token=${token}` });

    // opcional: gerar JWT de acesso (se JWT_SECRET presente)
    let jwtToken = null;
    const JWT_SECRET = process.env.JWT_SECRET;
    if (JWT_SECRET) {
      jwtToken = jwt.sign({ sub: userId, role: ROLES.MASTER, empresa: empresaId }, JWT_SECRET, { expiresIn: '7d' });
    }

    return res.json({ ok: true, userId, empresaId, jwt: jwtToken, mail: mailRes && mailRes.dev ? { confirmUrl: mailRes.confirmUrl } : null });
  } catch (err) {
    console.error('Erro no register', err);
    return res.status(500).json({ error: 'Erro interno' });
  }
});

// Confirmar e-mail
app.get('/auth/confirm', async (req, res) => {
  const { token } = req.query || {};
  if (!token) return res.status(400).send('Token requerido');
  try {
    const row = await db('email_tokens').where({ token, used: false }).first();
    if (!row) return res.status(400).send('Token inválido ou já usado');
    if (row.expires_at && new Date(row.expires_at) < new Date()) return res.status(400).send('Token expirado');

    // marcar usuário confirmado e token usado
    await db('usuarios').where({ id: row.user_id }).update({ email_confirmed: true });
    await db('email_tokens').where({ id: row.id }).update({ used: true });

    // buscar empresa para redirecionar para escolher plano
    const user = await db('usuarios').where({ id: row.user_id }).first();
    const empresa = user ? user.empresa_id : null;
    const frontend = process.env.FRONTEND_URL || 'http://localhost:3001';
    // redirect to choose plan page with empresa id
    return res.redirect(`${frontend}/choose-plan.html?empresa=${empresa}&token=${token}`);
  } catch (err) {
    console.error('Erro confirmando token', err);
    return res.status(500).send('Erro interno');
  }
});

// Auth routes
const authController = require('./controllers/auth.controller');
app.post('/auth/login', express.json(), authController.login);

// ---------- Exemplo de rotas protegidas por permissões ----------

// Criar empresa (apenas usuários com permissão de gerenciar empresas) - verifica limite por plano
const { requireModule, checkUserLimit, checkCompanyLimit } = require('./middleware/plan.middleware');
app.post('/api/companies', requirePermission(PERMISSIONS.MANAGE_COMPANIES), checkCompanyLimit(), async (req, res) => {
  const { razao_social, cnpj, telefone, email } = req.body || {};
  if (!razao_social || !cnpj) return res.status(400).json({ error: 'Campos obrigatórios: razao_social, cnpj' });
  const id = uuidv4();
  try {
    // checar unicidade de CNPJ
    const digits = String(cnpj || '').replace(/\D/g, '');
    const exist = await db('empresas').where({ cnpj: digits }).first();
    if (exist) return res.status(400).json({ error: 'CNPJ já cadastrado' });
    await db('empresas').insert({ id, razao_social, cnpj: digits, telefone, email });
    res.json({ ok: true, id });
  } catch (err) {
    console.error('Erro ao criar empresa', err);
    res.status(500).json({ error: 'Erro ao criar empresa' });
  }
});

// Remover empresa (apenas master/admin conforme permissão)
app.delete('/api/companies/:id', requirePermission(PERMISSIONS.MANAGE_COMPANIES), async (req, res) => {
  const { id } = req.params;
  try {
    await db('empresas').where({ id }).del();
    res.json({ ok: true });
  } catch (err) {
    console.error('Erro ao deletar empresa', err);
    res.status(500).json({ error: 'Erro ao deletar empresa' });
  }
});

// Criar usuário: admin pode criar usuários exceto 'master'
app.post('/api/users', requireRole(ROLES.ADMIN, ROLES.MASTER), checkUserLimit(), async (req, res) => {
  const { empresa_id, nome, email, telefone, senha_hash, role } = req.body || {};
  if (!empresa_id || !nome || !email || !role) return res.status(400).json({ error: 'Campos obrigatórios: empresa_id, nome, email, role' });
  // admin não pode criar master
  if (role === ROLES.MASTER && req.user.role !== ROLES.MASTER) {
    return res.status(403).json({ error: 'Apenas MASTER pode criar usuário MASTER' });
  }
  const id = uuidv4();
  try {
    await db('usuarios').insert({ id, empresa_id, nome, email, telefone, senha_hash, role });
    res.json({ ok: true, id });
  } catch (err) {
    console.error('Erro ao criar usuário', err);
    res.status(500).json({ error: 'Erro ao criar usuário' });
  }
});

// Alterar status de usuário (apenas MASTER pode alterar qualquer usuário)
app.put('/api/users/:id/status', requirePermission(PERMISSIONS.CHANGE_USER_STATUS_ANY), async (req, res) => {
  const { id } = req.params;
  const { status } = req.body || {};
  if (!status) return res.status(400).json({ error: 'Status requerido' });
  try {
    await db('usuarios').where({ id }).update({ status });
    res.json({ ok: true });
  } catch (err) {
    console.error('Erro ao atualizar status', err);
    res.status(500).json({ error: 'Erro ao atualizar status' });
  }
});

// Exemplo: rota financeira acessível apenas para role financeiro
app.get('/api/financeiro/reports', requirePermission(PERMISSIONS.FINANCEIRO_ACCESS), (req, res) => {
  res.json({ ok: true, msg: 'Acesso a relatórios financeiros' });
});

// Exemplo: rota comercial
app.get('/api/comercial/dashboard', requirePermission(PERMISSIONS.COMERCIAL_ACCESS), (req, res) => {
  res.json({ ok: true, msg: 'Dashboard comercial' });
});

function isValidEmail(email){
  return typeof email === 'string' && /\S+@\S+\.\S+/.test(email);
}

app.post('/api/contact', async (req, res) => {
  const { name, company, cnpj, email, phone, reason, message } = req.body || {};
  if (!name || !company || !email || !phone) {
    return res.status(400).json({ error: 'Campos obrigatórios: name, company, email, phone' });
  }
  if (!isValidEmail(email)) {
    return res.status(400).json({ error: 'Email inválido' });
  }

  const entry = {
    id: Date.now(),
    name: String(name),
    company: String(company),
    cnpj: cnpj ? String(cnpj) : null,
    email: String(email),
    phone: String(phone),
    reason: reason ? String(reason) : 'Outros',
    message: message ? String(message) : null,
    createdAt: new Date().toISOString()
  };

  try {
    const raw = fs.readFileSync(contactsFile, 'utf8');
    const arr = JSON.parse(raw);
    arr.push(entry);
    fs.writeFileSync(contactsFile, JSON.stringify(arr, null, 2));
    console.log('Novo contato:', entry);
    // attempt to send email to consultant
    try {
      const mailRes = await sendContactEmail(process.env.CONTACT_EMAIL || 'consultororganizado@gmail.com', entry);
      if (process.env.DEBUG_MAIL === 'true') {
        // when debugging, return mail result so developer can see preview URL/info
        return res.json({ ok: true, mail: mailRes });
      }
    } catch (mailErr) {
      console.error('Erro ao enviar email de contato:', mailErr);
      // continue — do not fail the request because of email issues
    }
    res.json({ ok: true });
  } catch (err) {
    console.error('Erro ao salvar contato', err);
    res.status(500).json({ error: 'Erro ao salvar contato' });
  }
});

// Helper: simple GET JSON with timeout using native http/https
const http = require('http');
const https = require('https');
const { URL } = require('url');

function fetchJsonWithTimeout(rawUrl, timeoutMs = 8000) {
  return new Promise((resolve, reject) => {
    let urlObj;
    try { urlObj = new URL(rawUrl); } catch (err) { return reject(new Error('URL inválida')) }

    const lib = urlObj.protocol === 'https:' ? https : http;
    const req = lib.get(urlObj, { timeout: timeoutMs, headers: { 'User-Agent': 'gp-finance/1.0' } }, (res) => {
      const { statusCode } = res;
      let raw = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => raw += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(raw);
          if (statusCode >= 400) return reject(new Error(`HTTP ${statusCode}`));
          resolve(parsed);
        } catch (e) {
          // sometimes API returns plain text
          if (statusCode >= 400) return reject(new Error(`HTTP ${statusCode}`));
          try { resolve(JSON.parse(raw || '{}')); } catch(_) { resolve({ raw }); }
        }
      });
    });

    req.on('error', (err) => reject(err));
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

// Rota para consultar CNPJ (consulta um serviço público como receitaws)
app.get('/api/cnpj/:cnpj', async (req, res) => {
  try {
    const raw = String(req.params.cnpj || '');
    const digits = raw.replace(/\D/g, '');
    if (digits.length !== 14) return res.status(400).json({ error: 'CNPJ inválido (aguarda 14 dígitos)' });

    // usar receitaws (limite de requisições público) — o backend atua como proxy para evitar CORS
    const url = `https://www.receitaws.com.br/v1/cnpj/${digits}`;
    const timeoutMs = parseInt(process.env.CNPJ_LOOKUP_TIMEOUT_MS || '8000', 10);
    const data = await fetchJsonWithTimeout(url, timeoutMs);

    // receitaws returns 'status' with 'ERROR' or data fields; forward useful fields
    if (data && data.status && data.status.toLowerCase() === 'error') {
      return res.status(502).json({ error: data.message || 'Erro na consulta externa', details: data });
    }

    // map common fields
    const razao_social = data.nome || data.razao_social || data.nome_fantasia || null;
    const fantasia = data.fantasia || data.nome_fantasia || null;

    return res.json({ ok: true, data: data, razao_social, fantasia });
  } catch (err) {
    console.error('Erro ao consultar CNPJ', err && err.message ? err.message : err);
    return res.status(500).json({ error: 'Falha ao consultar CNPJ', details: String(err && err.message ? err.message : err) });
  }
});

app.listen(port, () => {
  console.log(`Backend iniciado na porta ${port}`);
});
