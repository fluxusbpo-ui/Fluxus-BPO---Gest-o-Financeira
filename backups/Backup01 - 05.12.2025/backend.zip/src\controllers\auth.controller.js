const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const mailer = require('../config/mailer');
const { ROLES } = require('../roles');

async function register(req, res) {
  const { razao_social, cnpj, nome_responsavel, telefone, email, senha, confirmar_senha } = req.body || {};
  if (!razao_social || !cnpj || !nome_responsavel || !email || !senha || !confirmar_senha) {
    return res.status(400).json({ error: 'Campos obrigatórios ausentes' });
  }
  if (senha !== confirmar_senha) return res.status(400).json({ error: 'Senhas não conferem' });

  const digits = (cnpj || '').toString().replace(/\D/g, '');
  if (![11,14].includes(digits.length)) {
    return res.status(400).json({ error: 'CNPJ/CPF inválido (esperado 11 ou 14 dígitos)'});
  }

  try {
    const existing = await db('usuarios').where({ email }).first();
    if (existing) return res.status(400).json({ error: 'Email já cadastrado' });

    const empresaId = uuidv4();
    await db('empresas').insert({ id: empresaId, razao_social, cnpj: digits, telefone, email });

    const userId = uuidv4();
    const senha_hash = bcrypt.hashSync(senha, 10);
    await db('usuarios').insert({ id: userId, empresa_id: empresaId, nome: nome_responsavel, email, telefone, senha_hash, role: ROLES.MASTER, email_confirmed: false });

    const token = uuidv4();
    const expiresAt = new Date(Date.now() + (1000 * 60 * 60 * 24));
    await db('email_tokens').insert({ id: uuidv4(), user_id: userId, token, expires_at: expiresAt });

    // If a plan was provided at registration, create an assinatura record.
    const { plan } = req.body || {};
    let assinaturaId = null;
    if (plan) {
      // try to find plan by id or by name (case-insensitive)
      let plano = await db('planos').where({ id: plan }).first();
      if (!plano) {
        plano = await db('planos').whereRaw('upper(nome) = ?', (plan || '').toUpperCase()).first();
      }
      if (plano) {
        assinaturaId = uuidv4();
        if ((plano.nome || '').toUpperCase() === 'FREE') {
          // activate immediately
          await db('assinaturas').insert({ id: assinaturaId, empresa_id: empresaId, plano_id: plano.id, stripe_subscription_id: null, checkout_session_id: null, status: 'ativa', inicio: new Date(), fim: null });
          await db('empresas').where({ id: empresaId }).update({ active: true });
        } else {
          // create pending assinatura (will be activated after checkout/webhook)
          await db('assinaturas').insert({ id: assinaturaId, empresa_id: empresaId, plano_id: plano.id, stripe_subscription_id: null, checkout_session_id: null, status: 'pendente', inicio: null, fim: null });
        }
      }
    }

    const mailRes = await mailer.sendConfirmationEmail(email, token, { confirmUrl: process.env.CONFIRM_URL || `http://localhost:3001/auth/confirm?token=${token}` });

    let jwtToken = null;
    const JWT_SECRET = process.env.JWT_SECRET;
    if (JWT_SECRET) {
      jwtToken = jwt.sign({ sub: userId, role: ROLES.MASTER, empresa: empresaId }, JWT_SECRET, { expiresIn: '7d' });
    }

    return res.json({ ok: true, userId, empresaId, jwt: jwtToken, mail: mailRes && mailRes.dev ? { confirmUrl: mailRes.confirmUrl } : null });
  } catch (err) {
    console.error('Erro no register', err);
    return res.status(500).json({ error: 'Erro interno' });
  }
}

module.exports = { register };

async function login(req, res) {
  const { email, senha } = req.body || {};
  if (!email || !senha) return res.status(400).json({ error: 'Email e senha são obrigatórios' });
  try {
    const user = await db('usuarios').where({ email }).first();
    if (!user) return res.status(400).json({ error: 'Credenciais inválidas' });
    const ok = bcrypt.compareSync(senha, user.senha_hash || '');
    if (!ok) return res.status(400).json({ error: 'Credenciais inválidas' });

    const JWT_SECRET = process.env.JWT_SECRET;
    if (JWT_SECRET) {
      const token = jwt.sign({ sub: user.id, role: user.role, empresa: user.empresa_id }, JWT_SECRET, { expiresIn: '7d' });
      return res.json({ ok: true, token });
    }

    // dev fallback token
    const devToken = `dev:${user.id}`;
    return res.json({ ok: true, token: devToken, warning: 'JWT_SECRET não configurado; usando token dev' });
  } catch (err) {
    console.error('Erro login', err);
    res.status(500).json({ error: 'Erro interno' });
  }
}

module.exports.login = login;
