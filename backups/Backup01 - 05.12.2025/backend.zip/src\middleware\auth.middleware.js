const jwt = require('jsonwebtoken');

// Middleware de autenticação: verifica JWT se presente, senão aceita headers de dev
function auth(req, res, next) {
  const authHeader = req.header('authorization');
  const JWT_SECRET = process.env.JWT_SECRET;
  if (authHeader && authHeader.startsWith('Bearer ') && JWT_SECRET) {
    const token = authHeader.slice(7);
    try {
      const payload = jwt.verify(token, JWT_SECRET);
      req.user = { id: payload.sub, role: payload.role || payload.role, empresa: payload.empresa };
      return next();
    } catch (err) {
      return res.status(401).json({ error: 'Token inválido' });
    }
  }
  // fallback dev: allow x-user-role header
  const role = req.header('x-user-role');
  const id = req.header('x-user-id') || null;
  req.user = { id, role: role || null };
  next();
}

module.exports = { auth };
