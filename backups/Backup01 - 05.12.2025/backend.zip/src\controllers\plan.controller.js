const { v4: uuidv4 } = require('uuid');
const db = require('../config/db');
const stripe = require('../config/stripe');

async function listPlans(req, res) {
  try {
    const planos = await db('planos').select('*');
    res.json({ ok: true, planos });
  } catch (err) {
    console.error('Erro listando planos', err);
    res.status(500).json({ error: 'Erro interno' });
  }
}

async function createCheckoutSession(req, res) {
  const { empresaId, planId, success_url, cancel_url } = req.body || {};
  if (!empresaId || !planId) return res.status(400).json({ error: 'empresaId e planId requeridos' });

  try {
    const plano = await db('planos').where({ id: planId }).first();
    if (!plano) return res.status(404).json({ error: 'Plano não encontrado' });

    // If Stripe configured, create a Checkout session
    if (stripe) {
      const session = await stripe.checkout.sessions.create({
        mode: 'subscription',
        payment_method_types: ['card'],
        line_items: [{ price: plano.stripe_price_id, quantity: 1 }],
        success_url: success_url || (process.env.FRONTEND_URL || 'http://localhost:3001') + '/success.html?session_id={CHECKOUT_SESSION_ID}',
        cancel_url: cancel_url || (process.env.FRONTEND_URL || 'http://localhost:3001') + '/cancel.html'
      });
      // Persist a pending assinatura record and store session id for mapping in webhook
      const assinId = uuidv4();
      await db('assinaturas').insert({ id: assinId, empresa_id: empresaId, plano_id: planId, stripe_subscription_id: null, checkout_session_id: session.id, status: 'pendente', inicio: null, fim: null });
      return res.json({ ok: true, sessionUrl: session.url, sessionId: session.id });
    }

    // Dev fallback: simulate a session URL
    const fakeSessionId = uuidv4();
    const fakeUrl = (process.env.FRONTEND_URL || 'http://localhost:3001') + `/fake-checkout?session=${fakeSessionId}`;
    const assinId = uuidv4();
    await db('assinaturas').insert({ id: assinId, empresa_id: empresaId, plano_id: planId, stripe_subscription_id: null, checkout_session_id: fakeSessionId, status: 'pendente', inicio: null, fim: null });
    return res.json({ ok: true, sessionUrl: fakeUrl, sessionId: fakeSessionId });
  } catch (err) {
    console.error('Erro criando session', err);
    res.status(500).json({ error: 'Erro interno' });
  }
}

// Webhook handler: accepts real Stripe webhook or a dev-friendly JSON payload
async function handleWebhook(req, res) {
  try {
    if (stripe && process.env.STRIPE_WEBHOOK_SECRET) {
      const sig = req.headers['stripe-signature'];
      let event;
      try {
        event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
      } catch (err) {
        console.error('Signature verification failed', err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
      }
      // handle relevant event types
      if (event.type === 'invoice.payment_succeeded' || event.type === 'checkout.session.completed' || event.type === 'customer.subscription.created') {
        const data = event.data.object;
        // attempt to find subscription id
        const stripeSubscriptionId = data.subscription || data.id || null;
        // Attempt to map to our pending assinatura by stripe_subscription_id or other logic
        // For robust handling, store mapping when session was created.
        // Here we try to find assinaturas with matching stripe_subscription_id
        if (stripeSubscriptionId) {
          const assin = await db('assinaturas').where({ stripe_subscription_id: stripeSubscriptionId }).first();
          if (assin) {
            await db('assinaturas').where({ id: assin.id }).update({ status: 'ativa', inicio: new Date(), stripe_subscription_id: stripeSubscriptionId });
            await db('empresas').where({ id: assin.empresa_id }).update({ active: true });
          }
        }
      }
      return res.json({ received: true });
    }

    // Dev fallback: expect JSON body with { event:'subscription_activated', stripe_subscription_id, plan_id, empresa_id }
    const body = req.body || {};
    if (body.event === 'subscription_activated') {
      const { stripe_subscription_id, plan_id, empresa_id } = body;
      const assinId = uuidv4();
      await db('assinaturas').insert({ id: assinId, empresa_id, plano_id: plan_id, stripe_subscription_id, status: 'ativa', inicio: new Date(), fim: null });
      await db('empresas').where({ id: empresa_id }).update({ active: true });
      return res.json({ ok: true });
    }

    res.status(400).json({ error: 'Evento desconhecido' });
  } catch (err) {
    console.error('Erro no webhook', err);
    res.status(500).json({ error: 'Erro interno' });
  }
}

module.exports = { listPlans, createCheckoutSession, handleWebhook };
