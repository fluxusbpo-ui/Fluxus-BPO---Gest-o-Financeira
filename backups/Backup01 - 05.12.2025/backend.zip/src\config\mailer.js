// Re-exporta o mailer já implementado
module.exports = require('../mailer');
