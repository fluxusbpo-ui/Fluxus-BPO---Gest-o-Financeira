const { v4: uuidv4 } = require('uuid');

exports.seed = async function(knex) {
  // Deletes ALL existing entries
  await knex('planos').del();

  const plans = [
    {
      id: uuidv4(),
      nome: 'FREE',
      stripe_price_id: null,
      max_empresas: 1,
      max_usuarios: 2,
      preco_mensal: 0,
      funcionalidades: JSON.stringify({}),
      modulos: JSON.stringify({
        comercial: true,
        compras: true,
        financeiro: true,
        conciliacao: false,
        relatorios_avancados: false,
        documentos_fiscais: false,
        ia_insights: false
      })
    },
    {
      id: uuidv4(),
      nome: 'ESSENCIAL',
      stripe_price_id: null,
      max_empresas: 1,
      max_usuarios: 3,
      preco_mensal: 99,
      funcionalidades: JSON.stringify({}),
      modulos: JSON.stringify({
        comercial: true,
        compras: true,
        financeiro: true,
        conciliacao: true,
        relatorios_avancados: true,
        documentos_fiscais: true,
        ia_insights: false
      })
    },
    {
      id: uuidv4(),
      nome: 'PRO',
      stripe_price_id: null,
      max_empresas: 5,
      max_usuarios: 10,
      preco_mensal: 199,
      funcionalidades: JSON.stringify({}),
      modulos: JSON.stringify({
        comercial: true,
        compras: true,
        financeiro: true,
        conciliacao: true,
        relatorios_avancados: true,
        documentos_fiscais: true,
        ia_insights: true
      })
    },
    {
      id: uuidv4(),
      nome: 'ENTERPRISE',
      stripe_price_id: null,
      max_empresas: 20,
      max_usuarios: 0, // 0 → ilimitado
      preco_mensal: 499,
      funcionalidades: JSON.stringify({}),
      modulos: JSON.stringify({
        comercial: true,
        compras: true,
        financeiro: true,
        conciliacao: true,
        relatorios_avancados: true,
        documentos_fiscais: true,
        ia_insights: true,
        suporte_prioritario: true
      })
    }
  ];

  await knex('planos').insert(plans.map(p => ({
    id: p.id,
    nome: p.nome,
    stripe_price_id: p.stripe_price_id,
    max_empresas: p.max_empresas,
    max_usuarios: p.max_usuarios,
    preco_mensal: p.preco_mensal,
    funcionalidades: p.funcionalidades,
    modulos: p.modulos
  })));
};
